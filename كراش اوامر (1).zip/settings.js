
const fs = require("fs");
const chalk = require("chalk")

global.BOT_TOKEN = "8710611123:AAFkKCh7pA5pV7trgyWUO8Wztqx6Y7OjuoE" // create bot here https://t.me/Botfather and get bot token
global.BOT_NAME = "- 𝑰𝑻𝑺 »Alsohagy CRASH BOT»࿅ 𓈪" //your bot name
global.OWNER_NAME = "https://t.me/@X_3GR" //your name with sign @
global.OWNER = ["https://t.me/Alsohagy10", "https://t.me/Alsohagy10"] // Make sure the username is correct so that the special owner features can be used.
global.DEVELOPER = ["8245042236"] //developer telegram id to operate addprem delprem and listprem
global.pp = 'https://mora-host.zya.me/IMG_20260205_112143_469.jpg' //your bot pp


//approval
global.GROUP_ID = -1003887486572; // Replace with your group ID
global.CHANNEL_ID =  -1003887486572; // Replace with your channel ID
global.GROUP_LINK = "https://t.me/alsohagynumberotp1"; // Replace with your group link
global.CHANNEL_INVITE_LINK = "https://t.me/alsohagyalmalooon"; // Replace with your private channel invite link
global.WHATSAPP_LINK = "https://wa.me/201040942450"; // Replace with your group link
global.Telegram_LINK = "https://t.me/alsohagyalmalooon"; // Replace with your youtube link
global.INSTAGRAM_LINK = "https://www.instagram.com/Kimo_alsohagy?igsh=MWRnNW1zcXNxOTBrOA=="; // Replace with your ig link

global.owner = global.owner = ['+201040942450'] //owner whatsapp

const {
   english
} = require("./lib");
global.language = english
global.lang = language

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})